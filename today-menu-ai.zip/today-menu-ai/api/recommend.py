from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route("/recommend", methods=["POST"])
def recommend_menu():
    data = request.get_json()

    print("받은 데이터:", data)

    meal_style = data.get("mealStyle", "")
    preferred_food = data.get("preferredFood", "")
    avoid_food = data.get("avoidFood", "")

    try:
        budget = int(data.get("budget", 0))
    except:
        budget = 0

    result = {
        "breakfast": {
            "menu": f"{preferred_food} 계란 토스트와 바나나",
            "description": f"{meal_style} 스타일에 맞춘 가벼운 아침 메뉴입니다. {avoid_food}은 제외했습니다.",
            "cost": int(budget * 0.2)
        },
        "lunch": {
            "menu": f"{preferred_food} 비빔밥",
            "description": f"점심은 든든하게 먹을 수 있는 한식 메뉴로 추천합니다. {avoid_food}은 피했습니다.",
            "cost": int(budget * 0.4)
        },
        "dinner": {
            "menu": f"{preferred_food} 닭가슴살 샐러드",
            "description": f"저녁은 부담이 적고 건강한 메뉴로 구성했습니다. {avoid_food}은 포함하지 않았습니다.",
            "cost": int(budget * 0.4)
        }
    }

    return jsonify(result)

if __name__ == "__main__":
    print("서버를 시작합니다...")
    app.run(debug=True)