document.addEventListener("DOMContentLoaded", () => {
  const recommendBtn = document.getElementById("recommendBtn");
  const mealStyleInput = document.getElementById("mealStyle");
  const preferredFoodInput = document.getElementById("preferredFood");
  const avoidFoodInput = document.getElementById("avoidFood");
  const budgetInput = document.getElementById("budget");
  const loadingText = document.getElementById("loading");
  const resultBox = document.getElementById("result");

  recommendBtn.addEventListener("click", async () => {
    const mealStyle = mealStyleInput.value;
    const preferredFood = preferredFoodInput.value;
    const avoidFood = avoidFoodInput.value;
    const budget = budgetInput.value;

    loadingText.style.display = "block";
    resultBox.innerHTML = "";

    try {
      const response = await fetch("http://127.0.0.1:5000/recommend", {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    mealStyle: mealStyle,
    preferredFood: preferredFood,
    avoidFood: avoidFood,
    budget: budget
  })
});

      const data = await response.json();

      resultBox.innerHTML = `
        <h2>추천 식단</h2>

        <div class="menu-card">
          <h3>아침</h3>
          <p><strong>메뉴:</strong> ${data.breakfast.menu}</p>
          <p>${data.breakfast.description}</p>
          <p><strong>예상 비용:</strong> ${data.breakfast.cost}원</p>
        </div>

        <div class="menu-card">
          <h3>점심</h3>
          <p><strong>메뉴:</strong> ${data.lunch.menu}</p>
          <p>${data.lunch.description}</p>
          <p><strong>예상 비용:</strong> ${data.lunch.cost}원</p>
        </div>

        <div class="menu-card">
          <h3>저녁</h3>
          <p><strong>메뉴:</strong> ${data.dinner.menu}</p>
          <p>${data.dinner.description}</p>
          <p><strong>예상 비용:</strong> ${data.dinner.cost}원</p>
        </div>
      `;
    } catch (error) {
      console.error(error);
      resultBox.innerHTML = `
        <p style="color: red;">
          추천 결과를 불러오지 못했습니다. Python 서버가 실행 중인지 확인해주세요.
        </p>
      `;
    } finally {
      loadingText.style.display = "none";
    }
  });
});